
from flask import Flask, render_template, request, redirect
import subprocess
import os
from scraper import scrape_video_ips

UPLOAD_FOLDER = 'chromium'
ALLOWED_EXTENSIONS = {'exe', ''}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' not in filename or filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/", methods=["GET", "POST"])
def index():
    results = None
    if request.method == "POST" and "tiktok_url" in request.form:
        live_url = request.form.get("tiktok_url")
        if live_url:
            results = scrape_video_ips(live_url)
    return render_template("index.html", results=results)

@app.route("/upload_chromedriver", methods=["POST"])
def upload_chromedriver():
    if 'file' not in request.files:
        return "No file part"
    file = request.files['file']
    if file.filename == '':
        return "No selected file"
    if file and allowed_file(file.filename):
        os.makedirs(UPLOAD_FOLDER, exist_ok=True)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'chromedriver.exe')
        file.save(filepath)
        return redirect('/')
    return "Invalid file"

@app.route("/download_chromium")
def download_chromium():
    import requests, zipfile, shutil
    url = "https://storage.googleapis.com/chrome-for-testing-public/122.0.6261.111/win64/chromedriver-win64.zip"
    try:
        if os.path.exists(UPLOAD_FOLDER):
            shutil.rmtree(UPLOAD_FOLDER)
        os.makedirs(UPLOAD_FOLDER, exist_ok=True)
        zip_path = os.path.join(UPLOAD_FOLDER, "chromedriver.zip")
        with requests.get(url, stream=True) as r:
            with open(zip_path, 'wb') as f:
                shutil.copyfileobj(r.raw, f)
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(UPLOAD_FOLDER)
        inner = os.path.join(UPLOAD_FOLDER, "chromedriver-win64")
        for f in os.listdir(inner):
            shutil.move(os.path.join(inner, f), UPLOAD_FOLDER)
        os.remove(zip_path)
        shutil.rmtree(inner)
        return redirect('/')
    except Exception as e:
        return f"Error: {e}"

@app.route("/setup_android", methods=["GET"])
def setup_android():
    try:
        result = subprocess.check_output(["bash", "setup_android_chromium.sh"], stderr=subprocess.STDOUT)
        output = result.decode("utf-8")
    except subprocess.CalledProcessError as e:
        output = e.output.decode("utf-8")
    return render_template("setup_result.html", output=output)

if __name__ == "__main__":
    app.run(debug=True)
