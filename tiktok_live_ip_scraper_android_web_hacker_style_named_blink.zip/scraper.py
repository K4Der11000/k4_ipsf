
import re
import time
import socket
import platform
import os
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

def extract_ip_from_url(url):
    try:
        host = url.split('/')[2].split(':')[0]
        ip = socket.gethostbyname(host)
        return ip
    except:
        return "IP Not Found"

def get_chromedriver_path():
    system = platform.system().lower()
    if 'linux' in system:
        path = './chromium/chromedriver'
        if not os.path.exists(path):
            path = '/data/data/com.termux/files/usr/bin/chromedriver'
        return path
    elif 'windows' in system:
        return './chromium/chromedriver.exe'
    else:
        return './chromium/chromedriver'

def scrape_video_ips(live_url):
    chrome_options = Options()
    chrome_options.add_argument('--headless=new')
    chrome_options.add_argument('--disable-gpu')
    chrome_options.add_argument('--no-sandbox')
    driver = webdriver.Chrome(executable_path=get_chromedriver_path(), options=chrome_options)
    video_data = []
    try:
        driver.get(live_url)
        time.sleep(10)
        logs = driver.get_log('performance')
        seen = set()
        for entry in logs:
            msg = entry['message']
            urls = re.findall(r'https://[^"]+?\.(?:m3u8|ts)', msg)
            for url in urls:
                if url not in seen:
                    seen.add(url)
                    ip = extract_ip_from_url(url)
                    video_data.append((url, ip))
    except Exception as e:
        video_data.append((f"Error while scraping: {e}", ""))
    finally:
        driver.quit()
    return video_data
