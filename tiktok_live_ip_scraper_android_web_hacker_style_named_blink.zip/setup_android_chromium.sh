
#!/bin/bash

echo "[+] Starting Android setup..."

pkg update -y && pkg upgrade -y
pkg install -y python clang git wget unzip
pip install --upgrade pip
pip install flask selenium requests

mkdir -p ~/chromium
cd ~/chromium

echo "[+] Downloading chromedriver..."
wget -O chromedriver.zip "https://storage.googleapis.com/chrome-for-testing-public/122.0.6261.111/linux64/chromedriver-linux64.zip"
unzip chromedriver.zip
mv chromedriver-linux64/chromedriver .
chmod +x chromedriver
rm -rf chromedriver.zip chromedriver-linux64

if [ -d "/data/data/com.termux/files/usr/bin" ]; then
    cp chromedriver /data/data/com.termux/files/usr/bin/
    chmod +x /data/data/com.termux/files/usr/bin/chromedriver
    echo "[+] chromedriver moved to system path"
fi

echo "[✓] Setup completed successfully!"
