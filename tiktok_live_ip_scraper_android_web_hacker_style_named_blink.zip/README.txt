
TikTok Live IP Extractor (Web-based)

1. Requirements:
   - Python 3.x
   - pip install flask selenium requests
   - chromedriver in "chromium" folder

2. To run on Windows/Linux:
   python app.py

3. To run on Android (Termux or Pydroid):
   bash setup_android_chromium.sh
   python app.py

Then open your browser at http://127.0.0.1:5000

Enjoy!
